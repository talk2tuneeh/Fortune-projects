# glowy hover effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/talk2tuneeh/pen/oNVpMry](https://codepen.io/talk2tuneeh/pen/oNVpMry).

Inspired by the hover effects in Linear's features page