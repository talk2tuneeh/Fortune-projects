document.addEventListener('DOMContentLoaded', function() {
    const apiKey = '288759da27b8e5aacb13bd899ddd77c2';
    const weatherWidget = document.getElementById('weather-widget');

    function getWeather(city) {
        const apiUrl = 'https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${288759da27b8e5aacb13bd899ddd77c2}&units=metric';
        
        fetch(apiUrl)
            .then(response => response.json())
            .then(data => {
                displayWeather(data);
            })
            .catch(error => {
                console.error('Error fetching weather data:', error);
            })
    }

    function displayWeather(data) {
        const temperature = data.main.temp;
        const description = data.weather[0].description;

        weatherWidget.innerHTML = `
            <h2>${data.name}, ${data.sys.country}</h2>
            <p>${description}</p>
            <p>${temperature}°C</p>
        `;

    }
    getWeather('');
})